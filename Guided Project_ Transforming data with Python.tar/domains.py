import read
import pandas as pd

data= read.load_data()
domains_counts = data['url'].value_counts()
#print(domains_counts)
domains = domains_counts[:99:]
for name, row in domains.items():
    print("{0}: {1}".format(name, row))