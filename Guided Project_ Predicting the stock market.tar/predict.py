import pandas as pd
from datetime import datetime
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

stock = pd.read_csv("sphist.csv")
stock["Date"] = pd.to_datetime(stock["Date"])
stock["Date"] > datetime(year=2015, month=4, day=1)
stock.sort_values(by=['Date'],ascending=True)



stock['day_5'] = 0
stock['day_30'] = 0
stock['day_365'] = 0
print(stock[:2])

stock['day_5'] = stock['Close'].rolling(5).mean()
stock['day_5'] = stock['day_5'].shift()
stock['day_30'] = stock['Close'].rolling(30).mean()
stock['day_30'] = stock['day_30'].shift()
stock['day_365'] = stock['Close'].rolling(365).mean()
stock['day_365'] = stock['day_365'].shift()
stock

stock=stock[stock["Date"] > datetime(year=1951,month=1, day=3)]
stock=stock.dropna(axis=0)
train = stock[stock["Date"] < datetime(year=2013, month=1, day=1)]
train
test = stock[stock["Date"] > datetime(year=2013, month=1, day=1)]
test

lr= LinearRegression()

lr.fit(train[['day_5']],train[['Close']])
pre = lr.predict(test[['day_5']])
day5_mse = mean_squared_error(test['Close'],pre)
day5_mse

lr.fit(train[['day_30']],train[['Close']])
pre = lr.predict(test[['day_30']])
day30_mse = mean_squared_error(test['Close'],pre)
day30_mse

lr.fit(train[['day_365']],train[['Close']])
pre = lr.predict(test[['day_365']])
day365_mse = mean_squared_error(test['Close'],pre)
day365_mse

lr.fit(train[['day_5','day_30']],train[['Close']])
pre = lr.predict(test[['day_5','day_30']])
day5_30_mse = mean_squared_error(test['Close'],pre)
day5_30_mse


lr.fit(train[['day_5','day_30','day_365']],train[['Close']])
pre = lr.predict(test[['day_5','day_30','day_365']])
day5_30_365_mse = mean_squared_error(test['Close'],pre)
day5_30_365_mse
          
