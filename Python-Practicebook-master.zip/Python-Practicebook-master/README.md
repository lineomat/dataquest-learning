# Python-Practicebook
Python Notebook for data analysis practice and notes
